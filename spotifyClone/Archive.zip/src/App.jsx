import { useState } from 'react';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import Player from './components/Player';
import './App.css';

export const SONGS = [
  { id: 1, title: 'Blinding Lights', artist: 'The Weeknd', album: 'After Hours', duration: '3:20', cover: 'https://picsum.photos/seed/blinding/300/300' },
  { id: 2, title: 'Shape of You', artist: 'Ed Sheeran', album: 'Divide', duration: '3:53', cover: 'https://picsum.photos/seed/shapeof/300/300' },
  { id: 3, title: 'Levitating', artist: 'Dua Lipa', album: 'Future Nostalgia', duration: '3:23', cover: 'https://picsum.photos/seed/levitat/300/300' },
  { id: 4, title: 'Stay', artist: 'The Kid LAROI', album: 'F*ck Love', duration: '2:21', cover: 'https://picsum.photos/seed/staysong/300/300' },
  { id: 5, title: 'Peaches', artist: 'Justin Bieber', album: 'Justice', duration: '3:18', cover: 'https://picsum.photos/seed/peaches1/300/300' },
  { id: 6, title: 'Good 4 U', artist: 'Olivia Rodrigo', album: 'SOUR', duration: '2:58', cover: 'https://picsum.photos/seed/good4u/300/300' },
  { id: 7, title: 'Montero', artist: 'Lil Nas X', album: 'Montero', duration: '2:17', cover: 'https://picsum.photos/seed/montero1/300/300' },
  { id: 8, title: 'Kiss Me More', artist: 'Doja Cat', album: 'Planet Her', duration: '3:38', cover: 'https://picsum.photos/seed/kissme1/300/300' },
];

export const PLAYLISTS = [
  { id: 1, name: 'Chill Vibes', cover: 'https://picsum.photos/seed/chill1/300/300', songCount: 24 },
  { id: 2, name: 'Workout Hits', cover: 'https://picsum.photos/seed/workout2/300/300', songCount: 18 },
  { id: 3, name: 'Late Night Drive', cover: 'https://picsum.photos/seed/latenight3/300/300', songCount: 31 },
  { id: 4, name: 'Top Charts', cover: 'https://picsum.photos/seed/topcharts4/300/300', songCount: 50 },
  { id: 5, name: 'Indie Gems', cover: 'https://picsum.photos/seed/indiegems5/300/300', songCount: 15 },
  { id: 6, name: 'Throwback Jams', cover: 'https://picsum.photos/seed/throwback6/300/300', songCount: 40 },
];

export default function App() {
  const [currentSong, setCurrentSong] = useState(SONGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeNav, setActiveNav] = useState('home');
  const [volume, setVolume] = useState(70);
  const [progress, setProgress] = useState(30);
  const [liked, setLiked] = useState(new Set([1, 3]));
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);

  const toggleLike = (id) => {
    setLiked(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const playSong = (song) => {
    if (currentSong.id === song.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentSong(song);
      setIsPlaying(true);
      setProgress(0);
    }
  };

  const nextSong = () => {
    const idx = SONGS.findIndex(s => s.id === currentSong.id);
    const next = SONGS[(idx + 1) % SONGS.length];
    setCurrentSong(next);
    setIsPlaying(true);
    setProgress(0);
  };

  const prevSong = () => {
    const idx = SONGS.findIndex(s => s.id === currentSong.id);
    const prev = SONGS[(idx - 1 + SONGS.length) % SONGS.length];
    setCurrentSong(prev);
    setIsPlaying(true);
    setProgress(0);
  };

  return (
    <div className="app">
      <Sidebar activeNav={activeNav} setActiveNav={setActiveNav} playlists={PLAYLISTS} />
      <MainContent
        songs={SONGS}
        playlists={PLAYLISTS}
        currentSong={currentSong}
        isPlaying={isPlaying}
        liked={liked}
        toggleLike={toggleLike}
        playSong={playSong}
        activeNav={activeNav}
      />
      <Player
        currentSong={currentSong}
        isPlaying={isPlaying}
        setIsPlaying={setIsPlaying}
        volume={volume}
        setVolume={setVolume}
        progress={progress}
        setProgress={setProgress}
        liked={liked}
        toggleLike={toggleLike}
        nextSong={nextSong}
        prevSong={prevSong}
        shuffle={shuffle}
        setShuffle={setShuffle}
        repeat={repeat}
        setRepeat={setRepeat}
      />
    </div>
  );
}
